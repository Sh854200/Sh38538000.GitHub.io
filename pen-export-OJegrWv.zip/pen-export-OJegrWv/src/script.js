let flashlightOn = false;
let track;

async function toggleFlashlight() {
    const button = document.getElementById('flashlightBtn');

    if (!flashlightOn) {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
            track = stream.getVideoTracks()[0];
            const imageCapture = new ImageCapture(track);
            const photoCapabilities = await imageCapture.getPhotoCapabilities();

            if (photoCapabilities.fillLightMode.includes('flash')) {
                await track.applyConstraints({ advanced: [{ torch: true }] });
                flashlightOn = true;
                button.textContent = 'Turn Off Flashlight';
            } else {
                alert('Torch mode is not supported on this device.');
            }
        } catch (err) {
            console.error('Error accessing the camera or flashlight:', err);
            alert('An error occurred while trying to access the flashlight.');
        }
    } else {
        try {
            await track.applyConstraints({ advanced: [{ torch: false }] });
            track.stop();
            flashlightOn = false;
            button.textContent = 'Turn On Flashlight';
        } catch (err) {
            console.error('Error turning off the flashlight:', err);
            alert('An error occurred while trying to turn off the flashlight.');
        }
    }
}

document.getElementById('flashlightBtn').addEventListener('click', toggleFlashlight);
