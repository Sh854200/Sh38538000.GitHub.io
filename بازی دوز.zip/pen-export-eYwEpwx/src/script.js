const gameBoard = document.getElementById('gameBoard');
const statusDisplay = document.getElementById('status');
const resetButton = document.getElementById('resetButton');

let gameActive = true;
let currentPlayer = "X";
let gameState = ["", "", "", "", "", "", "", "", ""];

// برنده ها
const winningConditions = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
];

// ایجاد سلول های بازی
function createGameBoard() {
    for (let i = 0; i < 9; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.setAttribute('data-cell-index', i);
        cell.addEventListener('click', handleCellClick);
        gameBoard.appendChild(cell);
    }
}

// هندل کلیک روی سلول
function handleCellClick(event) {
    const clickedCell = event.target;
    const clickedCellIndex = parseInt(clickedCell.getAttribute('data-cell-index'));

    // بررسی وضعیت
    if (gameState[clickedCellIndex] !== "" || !gameActive) {
        return;
    }

    // ثبت حرکت
    gameState[clickedCellIndex] = currentPlayer;
    clickedCell.innerText = currentPlayer;
    clickedCell.classList.add(currentPlayer.toLowerCase()); // اضافه کردن کلاس با نام بازیکن
    validateResult();
}

// ارزیابی وضعیت بازی
function validateResult() {
    for (let i = 0; i < winningConditions.length; i++) {
        const [a, b, c] = winningConditions[i];
        if (gameState[a] === "" || gameState[b] === "" || gameState[c] === "") {
            continue;
        }
        if (gameState[a] === gameState[b] && gameState[a] === gameState[c]) {
            gameActive = false;
            displayResult(`بازیکن ${gameState[a]} برنده شد!`);
            return;
        }
    }

    // بررسی تساوی
    if (!gameState.includes("")) {
        gameActive = false;
        displayResult("تساوی!");
    } else {
        currentPlayer = currentPlayer === "X" ? "O" : "X";
    }
}

// نمایش نتیجه
function displayResult(message) {
    statusDisplay.innerText = message;
}

// ریست کردن بازی
resetButton.addEventListener('click', resetGame);

function resetGame() {
    gameActive = true;
    currentPlayer = "X";
    gameState = ["", "", "", "", "", "", "", "", ""];
    statusDisplay.innerText = "";
    document.querySelectorAll('.cell').forEach(cell => {
        cell.innerText = "";
        cell.classList.remove('x', 'o'); // حذف کلاس‌های قبلی
    });
}

createGameBoard();