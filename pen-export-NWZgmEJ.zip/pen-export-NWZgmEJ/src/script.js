// script.js
function handleOrientation(event) {
    // Get the compass heading from the device orientation
    let alpha = event.alpha; // Rotation around Z-axis
    if (alpha !== null) {
        // Rotate the needle based on the alpha value
        const needle = document.querySelector('.needle');
        needle.style.transform = `translateX(-50%) rotate(${-alpha}deg)`;
    }
}

// Check if DeviceOrientationEvent is supported
if (window.DeviceOrientationEvent) {
    window.addEventListener('deviceorientation', handleOrientation);
} else {
    alert("Device Orientation API not supported on your device.");
}
